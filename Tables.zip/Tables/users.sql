/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shopping_manage

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 07/06/2018 17:37:10
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `User_ID` int(11) UNSIGNED NOT NULL,
  `User_VName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `User_Password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `User_Telephone` float(37, 0) UNSIGNED NOT NULL,
  `User_Addr` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `User_Bank` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `User_Sex` bit(1) NULL DEFAULT NULL,
  `User_BirthDay` date NULL DEFAULT NULL,
  `User_Mail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `User_QQ` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci NULL DEFAULT NULL,
  `User_Wenxin` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`User_ID`) USING BTREE,
  INDEX `User_ID`(`User_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
