/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shopping_manage

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 07/06/2018 17:36:13
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cart-good
-- ----------------------------
DROP TABLE IF EXISTS `cart-good`;
CREATE TABLE `cart-good`  (
  `U_ID` int(11) UNSIGNED NOT NULL,
  `G_ID` int(11) UNSIGNED NOT NULL,
  `G_Price` decimal(10, 2) NULL DEFAULT NULL,
  `G_Num` int(11) NOT NULL,
  `G_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`U_ID`, `G_ID`) USING BTREE,
  INDEX `price`(`G_Price`) USING BTREE,
  INDEX `name`(`G_Name`) USING BTREE,
  CONSTRAINT `price` FOREIGN KEY (`G_Price`) REFERENCES `goods` (`g_price`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `name` FOREIGN KEY (`G_Name`) REFERENCES `goods` (`g_name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
