/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shopping_manage

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 07/06/2018 17:36:56
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `O_ID` int(11) UNSIGNED NOT NULL,
  `O_UserID` int(11) UNSIGNED NOT NULL,
  `O_GoodID` int(11) UNSIGNED NOT NULL,
  `O_DateTime` datetime(0) NOT NULL,
  `O_Number` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `O_Sum` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `O_Addr` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `O_Remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`O_ID`) USING BTREE,
  INDEX `O_UserID`(`O_UserID`) USING BTREE,
  INDEX `O_GoodID`(`O_GoodID`) USING BTREE,
  CONSTRAINT `O_UserID` FOREIGN KEY (`O_UserID`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `O_GoodID` FOREIGN KEY (`O_GoodID`) REFERENCES `goods` (`g_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
