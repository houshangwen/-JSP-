/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shopping_manage

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 07/06/2018 17:37:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user-cart
-- ----------------------------
DROP TABLE IF EXISTS `user-cart`;
CREATE TABLE `user-cart`  (
  `C_ID` int(11) NOT NULL,
  `UC_Sum` decimal(25, 2) UNSIGNED NOT NULL,
  PRIMARY KEY (`C_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
