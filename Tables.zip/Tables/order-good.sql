/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shopping_manage

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 07/06/2018 17:36:50
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for order-good
-- ----------------------------
DROP TABLE IF EXISTS `order-good`;
CREATE TABLE `order-good`  (
  `O_ID` int(11) NOT NULL,
  `G_ID` int(11) NOT NULL,
  `G_Price` decimal(10, 2) NULL DEFAULT NULL,
  `G_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `G_Num` int(11) NOT NULL,
  PRIMARY KEY (`O_ID`, `G_ID`) USING BTREE,
  INDEX `G_price`(`G_Price`) USING BTREE,
  INDEX `G_name`(`G_Name`) USING BTREE,
  CONSTRAINT `G_name` FOREIGN KEY (`G_Name`) REFERENCES `goods` (`g_name`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `G_price` FOREIGN KEY (`G_Price`) REFERENCES `goods` (`g_price`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
