/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shopping_manage

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 07/06/2018 17:36:39
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `G_ID` int(11) UNSIGNED NOT NULL,
  `G_Price` decimal(10, 2) UNSIGNED NOT NULL,
  `G_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `G_Number` int(11) UNSIGNED NOT NULL,
  `G_Photo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `G_Sales` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `G_Intro` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`G_ID`) USING BTREE,
  INDEX `G_Price`(`G_Price`) USING BTREE,
  INDEX `G_Price_2`(`G_Price`) USING BTREE,
  INDEX `G_Price_3`(`G_Price`) USING BTREE,
  INDEX `G_Price_4`(`G_Price`) USING BTREE,
  INDEX `G_Price_5`(`G_Price`) USING BTREE,
  INDEX `G_Price_6`(`G_Price`) USING BTREE,
  INDEX `G_Price_7`(`G_Price`) USING BTREE,
  INDEX `G_Price_8`(`G_Price`) USING BTREE,
  INDEX `G_Price_9`(`G_Price`) USING BTREE,
  INDEX `G_Name`(`G_Name`) USING BTREE,
  INDEX `G_Price_10`(`G_Price`) USING BTREE,
  INDEX `G_Price_11`(`G_Price`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
