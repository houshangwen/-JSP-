/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shop

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 17/06/2018 16:27:20
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for o-g
-- ----------------------------
DROP TABLE IF EXISTS `o-g`;
CREATE TABLE `o-g`  (
  `O_ID` int(10) UNSIGNED NOT NULL,
  `G_ID` int(10) UNSIGNED NOT NULL,
  `G_Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `G_Price` decimal(10, 2) UNSIGNED NOT NULL,
  `G_Num` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`O_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
