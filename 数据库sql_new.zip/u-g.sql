/*
 Navicat MySQL Data Transfer

 Source Server         : Web_Shopping
 Source Server Type    : MySQL
 Source Server Version : 80011
 Source Host           : localhost:3306
 Source Schema         : shop

 Target Server Type    : MySQL
 Target Server Version : 80011
 File Encoding         : 65001

 Date: 17/06/2018 16:27:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for u-g
-- ----------------------------
DROP TABLE IF EXISTS `u-g`;
CREATE TABLE `u-g`  (
  `U_ID` int(10) UNSIGNED NOT NULL,
  `G_ID` int(10) UNSIGNED NOT NULL,
  `Num` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`U_ID`) USING BTREE,
  INDEX `G_ID`(`G_ID`) USING BTREE,
  CONSTRAINT `G_ID` FOREIGN KEY (`G_ID`) REFERENCES `goods` (`g_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `U_ID` FOREIGN KEY (`U_ID`) REFERENCES `users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
